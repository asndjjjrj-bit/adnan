import { useQuery, useMutation } from "convex/react";
import { api } from "../convex/_generated/api";
import { Id } from "../convex/_generated/dataModel";
import { useState } from "react";
import { toast } from "sonner";

export function Dashboard() {
  const [activeTab, setActiveTab] = useState("tasks");
  const loggedInUser = useQuery(api.auth.loggedInUser);
  const tasks = useQuery(api.tasks.listTasks);
  const userTasks = useQuery(api.tasks.getUserTasks);
  const earnings = useQuery(api.earnings.getUserEarnings);
  const totalBalance = useQuery(api.earnings.getTotalBalance);
  const withdrawals = useQuery(api.earnings.getUserWithdrawals);

  const startTask = useMutation(api.tasks.startTask);
  const completeTask = useMutation(api.tasks.completeTask);
  const requestWithdrawal = useMutation(api.earnings.requestWithdrawal);

  const [withdrawalForm, setWithdrawalForm] = useState({
    amount: "",
    method: "paypal",
    accountDetails: "",
  });

  const handleStartTask = async (taskId: Id<"tasks">) => {
    try {
      await startTask({ taskId });
      toast.success("تم بدء المهمة بنجاح!");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "حدث خطأ");
    }
  };

  const handleCompleteTask = async (userTaskId: Id<"userTasks">, proof: string) => {
    try {
      await completeTask({ userTaskId, proof });
      toast.success("تم إرسال المهمة للمراجعة!");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "حدث خطأ");
    }
  };

  const handleWithdrawal = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await requestWithdrawal({
        amount: parseFloat(withdrawalForm.amount),
        method: withdrawalForm.method,
        accountDetails: withdrawalForm.accountDetails,
      });
      toast.success("تم إرسال طلب السحب!");
      setWithdrawalForm({ amount: "", method: "paypal", accountDetails: "" });
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "حدث خطأ");
    }
  };

  // Sample data for demonstration
  const sampleTasks = [
    {
      _id: "1" as Id<"tasks">,
      title: "مشاهدة فيديو على يوتيوب",
      description: "شاهد فيديو لمدة 5 دقائق واترك تعليق إيجابي",
      reward: 2,
      category: "وسائل التواصل",
      difficulty: "سهل",
      timeRequired: "5 دقائق",
      isActive: true,
    },
    {
      _id: "2" as Id<"tasks">, 
      title: "تحميل تطبيق جديد",
      description: "حمل التطبيق واستخدمه لمدة 10 دقائق",
      reward: 5,
      category: "تطبيقات",
      difficulty: "سهل",
      timeRequired: "10 دقائق",
      isActive: true,
    },
    {
      _id: "3" as Id<"tasks">,
      title: "إنشاء حساب على موقع",
      description: "أنشئ حساب جديد وأكمل ملفك الشخصي",
      reward: 8,
      category: "تسجيل",
      difficulty: "متوسط",
      timeRequired: "15 دقيقة",
      isActive: true,
    },
  ];

  const displayTasks = tasks && tasks.length > 0 ? tasks : sampleTasks;

  return (
    <div className="space-y-6">
      {/* Welcome Section */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-800 mb-2">
              مرحباً، {loggedInUser?.email?.split('@')[0] || "صديقي"}! 👋
            </h1>
            <p className="text-gray-600">ابدأ في كسب المال من خلال إكمال المهام البسيطة</p>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-green-600">
              ${totalBalance || 0}
            </div>
            <div className="text-sm text-gray-500">رصيدك الحالي</div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-white rounded-xl shadow-lg">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 px-6">
            {[
              { id: "tasks", label: "المهام المتاحة", icon: "📋" },
              { id: "myTasks", label: "مهامي", icon: "✅" },
              { id: "earnings", label: "الأرباح", icon: "💰" },
              { id: "withdraw", label: "سحب الأموال", icon: "🏦" },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`py-4 px-2 border-b-2 font-medium text-sm ${
                  activeTab === tab.id
                    ? "border-blue-500 text-blue-600"
                    : "border-transparent text-gray-500 hover:text-gray-700"
                }`}
              >
                <span className="mr-2">{tab.icon}</span>
                {tab.label}
              </button>
            ))}
          </nav>
        </div>

        <div className="p-6">
          {/* Available Tasks Tab */}
          {activeTab === "tasks" && (
            <div className="space-y-4">
              <h2 className="text-xl font-semibold mb-4">المهام المتاحة</h2>
              {displayTasks.map((task) => (
                <div key={task._id} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <h3 className="font-semibold text-lg mb-2">{task.title}</h3>
                      <p className="text-gray-600 mb-3">{task.description}</p>
                      <div className="flex gap-4 text-sm text-gray-500">
                        <span>🏷️ {task.category}</span>
                        <span>⏱️ {task.timeRequired}</span>
                        <span>📊 {task.difficulty}</span>
                      </div>
                    </div>
                    <div className="text-center ml-4">
                      <div className="text-2xl font-bold text-green-600 mb-2">
                        ${task.reward}
                      </div>
                      <button
                        onClick={() => handleStartTask(task._id)}
                        className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
                      >
                        ابدأ المهمة
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* My Tasks Tab */}
          {activeTab === "myTasks" && (
            <div className="space-y-4">
              <h2 className="text-xl font-semibold mb-4">مهامي</h2>
              {userTasks && userTasks.length > 0 ? (
                userTasks.map((userTask) => (
                  <div key={userTask._id} className="border rounded-lg p-4">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <h3 className="font-semibold text-lg mb-2">
                          {userTask.task?.title || "مهمة محذوفة"}
                        </h3>
                        <p className="text-gray-600 mb-3">
                          {userTask.task?.description || ""}
                        </p>
                        <div className="flex items-center gap-2">
                          <span className={`px-3 py-1 rounded-full text-sm ${
                            userTask.status === "pending" ? "bg-yellow-100 text-yellow-800" :
                            userTask.status === "completed" ? "bg-blue-100 text-blue-800" :
                            userTask.status === "approved" ? "bg-green-100 text-green-800" :
                            "bg-red-100 text-red-800"
                          }`}>
                            {userTask.status === "pending" ? "قيد التنفيذ" :
                             userTask.status === "completed" ? "مكتملة - في انتظار المراجعة" :
                             userTask.status === "approved" ? "مقبولة" : "مرفوضة"}
                          </span>
                        </div>
                      </div>
                      <div className="text-center ml-4">
                        <div className="text-xl font-bold text-green-600 mb-2">
                          ${userTask.task?.reward || 0}
                        </div>
                        {userTask.status === "pending" && (
                          <button
                            onClick={() => {
                              const proof = prompt("أدخل رابط الإثبات أو وصف ما قمت به:");
                              if (proof) {
                                handleCompleteTask(userTask._id, proof);
                              }
                            }}
                            className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors"
                          >
                            إكمال المهمة
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-8 text-gray-500">
                  لم تبدأ أي مهام بعد. ابدأ من تبويب "المهام المتاحة"
                </div>
              )}
            </div>
          )}

          {/* Earnings Tab */}
          {activeTab === "earnings" && (
            <div className="space-y-4">
              <h2 className="text-xl font-semibold mb-4">سجل الأرباح</h2>
              <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
                <div className="text-center">
                  <div className="text-3xl font-bold text-green-600 mb-2">
                    ${totalBalance || 0}
                  </div>
                  <div className="text-green-700">إجمالي الرصيد المتاح</div>
                </div>
              </div>
              
              {earnings && earnings.length > 0 ? (
                <div className="space-y-3">
                  {earnings.map((earning) => (
                    <div key={earning._id} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                      <div>
                        <div className="font-medium">{earning.description}</div>
                        <div className="text-sm text-gray-500">{earning.source}</div>
                      </div>
                      <div className="text-green-600 font-bold">+${earning.amount}</div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-gray-500">
                  لا توجد أرباح بعد. ابدأ بإكمال المهام لكسب المال!
                </div>
              )}
            </div>
          )}

          {/* Withdraw Tab */}
          {activeTab === "withdraw" && (
            <div className="space-y-6">
              <h2 className="text-xl font-semibold mb-4">سحب الأموال</h2>
              
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600 mb-2">
                    ${totalBalance || 0}
                  </div>
                  <div className="text-blue-700">الرصيد المتاح للسحب</div>
                  <div className="text-sm text-gray-600 mt-2">الحد الأدنى للسحب: $10</div>
                </div>
              </div>

              <form onSubmit={handleWithdrawal} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    المبلغ المراد سحبه
                  </label>
                  <input
                    type="number"
                    min="10"
                    step="0.01"
                    value={withdrawalForm.amount}
                    onChange={(e) => setWithdrawalForm({...withdrawalForm, amount: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    placeholder="أدخل المبلغ"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    طريقة السحب
                  </label>
                  <select
                    value={withdrawalForm.method}
                    onChange={(e) => setWithdrawalForm({...withdrawalForm, method: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="paypal">PayPal</option>
                    <option value="bank">تحويل بنكي</option>
                    <option value="crypto">عملة رقمية</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    تفاصيل الحساب
                  </label>
                  <input
                    type="text"
                    value={withdrawalForm.accountDetails}
                    onChange={(e) => setWithdrawalForm({...withdrawalForm, accountDetails: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    placeholder="أدخل بريد PayPal أو رقم الحساب"
                    required
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition-colors font-medium"
                >
                  طلب السحب
                </button>
              </form>

              {/* Withdrawal History */}
              <div className="mt-8">
                <h3 className="text-lg font-semibold mb-4">سجل طلبات السحب</h3>
                {withdrawals && withdrawals.length > 0 ? (
                  <div className="space-y-3">
                    {withdrawals.map((withdrawal) => (
                      <div key={withdrawal._id} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                        <div>
                          <div className="font-medium">${withdrawal.amount}</div>
                          <div className="text-sm text-gray-500">
                            {withdrawal.method} • {new Date(withdrawal.requestedAt).toLocaleDateString('ar')}
                          </div>
                        </div>
                        <span className={`px-3 py-1 rounded-full text-sm ${
                          withdrawal.status === "pending" ? "bg-yellow-100 text-yellow-800" :
                          withdrawal.status === "approved" ? "bg-blue-100 text-blue-800" :
                          withdrawal.status === "completed" ? "bg-green-100 text-green-800" :
                          "bg-red-100 text-red-800"
                        }`}>
                          {withdrawal.status === "pending" ? "قيد المراجعة" :
                           withdrawal.status === "approved" ? "موافق عليه" :
                           withdrawal.status === "completed" ? "مكتمل" : "مرفوض"}
                        </span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-4 text-gray-500">
                    لا توجد طلبات سحب سابقة
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
