import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

export const listTasks = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db
      .query("tasks")
      .filter((q) => q.eq(q.field("isActive"), true))
      .collect();
  },
});

export const getUserTasks = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    const userTasks = await ctx.db
      .query("userTasks")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .collect();

    const tasksWithDetails = await Promise.all(
      userTasks.map(async (userTask) => {
        const task = await ctx.db.get(userTask.taskId);
        return {
          ...userTask,
          task,
        };
      })
    );

    return tasksWithDetails;
  },
});

export const startTask = mutation({
  args: { taskId: v.id("tasks") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("يجب تسجيل الدخول أولاً");

    // Check if user already started this task
    const existingUserTask = await ctx.db
      .query("userTasks")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .filter((q) => q.eq(q.field("taskId"), args.taskId))
      .first();

    if (existingUserTask) {
      throw new Error("لقد بدأت هذه المهمة بالفعل");
    }

    return await ctx.db.insert("userTasks", {
      userId,
      taskId: args.taskId,
      status: "pending",
    });
  },
});

export const completeTask = mutation({
  args: { 
    userTaskId: v.id("userTasks"),
    proof: v.string(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("يجب تسجيل الدخول أولاً");

    const userTask = await ctx.db.get(args.userTaskId);
    if (!userTask || userTask.userId !== userId) {
      throw new Error("المهمة غير موجودة");
    }

    if (userTask.status !== "pending") {
      throw new Error("لا يمكن إكمال هذه المهمة");
    }

    await ctx.db.patch(args.userTaskId, {
      status: "completed",
      completedAt: Date.now(),
      proof: args.proof,
    });

    return { success: true };
  },
});
