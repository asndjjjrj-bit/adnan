import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

export const getUserEarnings = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    return await ctx.db
      .query("earnings")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("desc")
      .collect();
  },
});

export const getTotalBalance = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return 0;

    const earnings = await ctx.db
      .query("earnings")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .collect();

    const withdrawals = await ctx.db
      .query("withdrawals")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .filter((q) => q.neq(q.field("status"), "rejected"))
      .collect();

    const totalEarnings = earnings.reduce((sum, earning) => sum + earning.amount, 0);
    const totalWithdrawals = withdrawals.reduce((sum, withdrawal) => sum + withdrawal.amount, 0);

    return totalEarnings - totalWithdrawals;
  },
});

export const requestWithdrawal = mutation({
  args: {
    amount: v.number(),
    method: v.string(),
    accountDetails: v.string(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("يجب تسجيل الدخول أولاً");

    // Check if user has enough balance
    const earnings = await ctx.db
      .query("earnings")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .collect();

    const withdrawals = await ctx.db
      .query("withdrawals")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .filter((q) => q.neq(q.field("status"), "rejected"))
      .collect();

    const totalEarnings = earnings.reduce((sum, earning) => sum + earning.amount, 0);
    const totalWithdrawals = withdrawals.reduce((sum, withdrawal) => sum + withdrawal.amount, 0);
    const balance = totalEarnings - totalWithdrawals;

    if (args.amount > balance) {
      throw new Error("الرصيد غير كافي");
    }

    if (args.amount < 10) {
      throw new Error("الحد الأدنى للسحب هو 10 دولار");
    }

    return await ctx.db.insert("withdrawals", {
      userId,
      amount: args.amount,
      method: args.method,
      accountDetails: args.accountDetails,
      status: "pending",
      requestedAt: Date.now(),
    });
  },
});

export const getUserWithdrawals = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    return await ctx.db
      .query("withdrawals")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("desc")
      .collect();
  },
});
