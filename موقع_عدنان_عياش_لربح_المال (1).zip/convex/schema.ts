import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  tasks: defineTable({
    title: v.string(),
    description: v.string(),
    reward: v.number(),
    category: v.string(),
    difficulty: v.string(),
    timeRequired: v.string(),
    isActive: v.boolean(),
  }),
  
  userTasks: defineTable({
    userId: v.id("users"),
    taskId: v.id("tasks"),
    status: v.string(), // "pending", "completed", "approved", "rejected"
    completedAt: v.optional(v.number()),
    approvedAt: v.optional(v.number()),
    proof: v.optional(v.string()),
  }).index("by_user", ["userId"])
    .index("by_task", ["taskId"])
    .index("by_user_and_status", ["userId", "status"]),

  earnings: defineTable({
    userId: v.id("users"),
    amount: v.number(),
    source: v.string(),
    taskId: v.optional(v.id("tasks")),
    description: v.string(),
  }).index("by_user", ["userId"]),

  withdrawals: defineTable({
    userId: v.id("users"),
    amount: v.number(),
    method: v.string(),
    accountDetails: v.string(),
    status: v.string(), // "pending", "approved", "rejected", "completed"
    requestedAt: v.number(),
    processedAt: v.optional(v.number()),
  }).index("by_user", ["userId"])
    .index("by_status", ["status"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
